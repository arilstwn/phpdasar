<!DOCTYPE html>
<html>
<body>

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
  Name: <input type="text" name="fname">
  <br>
  <br>
  Umur: <input type="text" umur="umur">
  <br>
  <br>
  Gender:  <input type="radio" id="html" name="fav_language" value="HTML">
  <label for="html">Laki - laki</label>
          <input type="radio" id="html" name="fav_language" value="HTML">
  <label for="html">Perempuan</label>
          <input type="radio" id="html" name="fav_language" value="HTML">
  <label for="html">2D/cowok/cewek</label>
  <br>
  <br>
  Makanan Kesukaan: <input type="checkbox" id="Makanan" name="Makanan1" value="Susi">
  <label for="vehicle1">Susi</label>
                    <input type="checkbox" id="Makanan" name="Makanan2" value="Ramen">
  <label for="vehicle1">Ramen</label>
                    <input type="checkbox" id="Makanan" name="Makanan3" value="Makanan 2D">
  <label for="vehicle1">Makanan 2D</label><br>

  <input type="submit"> 
  
  <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field
    $name = $_POST['fname'];
    $Umur = $_POST['umur'];
    $gender = $_POST['gender'];
    $makanan = $_POST['makanan'];
    if (empty($name) && empty($umur) && empty($gender) && empty($makanan)) {
       
    } else {
       
        
    }
}
?>
</form>
 
</body>
</html>