<!DOCTYPE html>
<html lang="en">
<>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registrasi</title>
    <style>
        label {
            display: block;
        }
    </style>
     <style>
body {
  background-image: url('https://i.ytimg.com/vi/RgHiiuahpRU/hq720.jpg?sqp=-oaymwE7CK4FEIIDSFryq4qpAy0IARUAAAAAGAElAADIQj0AgKJD8AEB-AH-CYAC0AWKAgwIABABGGUgWChcMA8=&rs=AOn4CLBJOW24VsF677ErP2deDPgDrh-X-w');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
    </style>
    <style>
 .card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 50%;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 5px 0px;
}
</style>


    
    
</head>
<body>
    <center>
<div class="card">
<div class="container">
<div class="card w-50 m-auto p-6">
    <form action="connect_register.php" method="post">
        <h3 class="text-center"></h3>
        <h2 style="background-color:powderblue;">Register Dulu Bang</h2>
        <form action=""method="post">
        <label for="username"><h style="color:blue;">Username:</h></label>
        <input type="text" name="unsername" id="username"> 
          </div>
          
          <div class=>
                <label for="email"><h style="color:blue;">Email:</h></label>
                <input type="text" name="email" id="email"> 
          <br>
                <label for="password"><h style="color:blue;">Password:<h/></label>
                <input type="password" name="password" id="password"> 
          <br>
          <br>
                <button type="sumbit" name="login"><h style="color:blue">Register</h></button>

           
 
    </form>
    </div>
    </div>
    </center>          
</body>
</html> 