<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    
    <style>
      input {
        display: block;
      }
      </style>
    <body style="background-color:powderblue;">
      <style>
        body {
          background-image: url('https://anievo.id/wp-content/uploads/2022/02/elaina0.jpg');
          background-repeat: no-repeat;
          background-attachment: fixed; 
          background-size: 100% 100%;
        }
        
       h1 {
        border: 2px solid black;
  padding: 15px;
  background: url("https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2021/08/19/2664731026.png");
  background-repeat: repeat;
}
</style>
</head>
<body>
<section class="vh-100">
  <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <form action="connect_login.php" method="POST">
     <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
    
           <center><div class="w3-panel w3-border">
            <h1 style="color:white;">Login Dulu Bang</h1></div></center> 
           <!-- Email input -->
          <center><div class="form-outline mb-4">
          Email address:<input type="email" id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid email address" name="email"/>
            <label class="form-label" for="form3Example3"></label>
          </div>

          <!-- Password input -->
          <div class="form-outline mb-3">
          Password:<input type="password" id="form3Example4" class="form-control form-control-lg"
              placeholder="Enter password" name="password"/>
            <label class="form-label" for="form3Example4"></label>
          </div>

          <div class="d-flex justify-content-between align-items-center">

            <!-- Checkbox -->
        <div class="form-check mb-0">
              <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3" />
              <label class="form-check-label" for="form2Example3">
                Remember me
              </label>
            </div>
            <a href="https://i.pinimg.com/736x/d8/5a/2a/d85a2ab3cc2126cc85b74f15f7647824.jpg" class="text-body"><h style="color:blue;">Forgot password?</h></a>
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
            <button type="submit" class="btn btn-primary btn-lg"
              style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
            <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="https://w0.peakpx.com/wallpaper/32/709/HD-wallpaper-digital-art-artwork-2d-anime-anime-girls-portrait-display-vertical-majo-no-tabitabi-elaina-majo-no-tabitabi-silver-hair-blue-eyes-witch-witch-hat-snow-cherry-blossom-landscape-azuuru-thumbnail.jpg"
                class="link-danger"><h style="color:blue;">Register </h></a></p>
          </div>

        </form>
      </div>
    </div>
  </div>
  <div>
    <!-- Copyright -->
    <center><div class="text-white mb-3 mb-md-0">
      Copyright © 2023. All rights reserved.
    </div></center>
    <!-- Copyright -->

    <!-- Right -->
    <div>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-google"></i></center>
</body>
</html>